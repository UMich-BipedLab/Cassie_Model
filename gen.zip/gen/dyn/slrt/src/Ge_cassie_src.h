/*
 * Automatically Generated from Mathematica.
 * Wed 9 Jan 2019 17:13:07 GMT-05:00
 */

#ifndef GE_CASSIE_SRC_H
#define GE_CASSIE_SRC_H

#ifdef MATLAB_MEX_FILE
#include <tmwtypes.h>
#else
#include "rtwtypes.h"
#endif

void Ge_cassie_src(double *p_output1, const double *var1);

#endif 
/* GE_CASSIE_SRC_H */
