/*
 * Automatically Generated from Mathematica.
 * Wed 9 Jan 2019 17:18:08 GMT-05:00
 */

#ifndef CE_CASSIE_SRC_H
#define CE_CASSIE_SRC_H

#ifdef MATLAB_MEX_FILE
#include <tmwtypes.h>
#else
#include "rtwtypes.h"
#endif

void Ce_cassie_src(double *p_output1, const double *var1,const double *var2);

#endif 
/* CE_CASSIE_SRC_H */
