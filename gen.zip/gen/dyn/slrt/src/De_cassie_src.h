/*
 * Automatically Generated from Mathematica.
 * Wed 9 Jan 2019 17:13:04 GMT-05:00
 */

#ifndef DE_CASSIE_SRC_H
#define DE_CASSIE_SRC_H

#ifdef MATLAB_MEX_FILE
#include <tmwtypes.h>
#else
#include "rtwtypes.h"
#endif

void De_cassie_src(double *p_output1, const double *var1);

#endif 
/* DE_CASSIE_SRC_H */
