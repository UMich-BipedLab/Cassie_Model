/*
 * Automatically Generated from Mathematica.
 * Wed 9 Jan 2019 17:25:13 GMT-05:00
 */

#ifndef CE_CASSIE_H
#define CE_CASSIE_H
#include <Eigen/Dense>

Eigen::Matrix<double,20,20> Ce_cassie(const Eigen::Matrix<double,20,1> &var1, const Eigen::Matrix<double,20,1> &var2);

#endif 


