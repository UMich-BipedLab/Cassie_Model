/*
 * Automatically Generated from Mathematica.
 * Wed 9 Jan 2019 17:20:05 GMT-05:00
 */

#ifndef GE_CASSIE_H
#define GE_CASSIE_H
#include <Eigen/Dense>

Eigen::Matrix<double,20,1> Ge_cassie(const Eigen::Matrix<double,20,1> &var1);

#endif 


