/*
 * Automatically Generated from Mathematica.
 * Fri 18 Jan 2019 14:01:46 GMT-05:00
 */

#ifndef BE_CASSIE_H
#define BE_CASSIE_H
#include <Eigen/Dense>

Eigen::Matrix<double,20,10> Be_cassie(const Eigen::Matrix<double,20,1> &var1);

#endif 


