/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:06 GMT-05:00
 */

#ifndef JP_BASEROTZ_H
#define JP_BASEROTZ_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,20> Jp_BaseRotZ(const Eigen::Matrix<double,20,1> &var1);

#endif 


