/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 23:02:38 GMT-05:00
 */

#ifndef P_VECTORNAV_TO_RIGHTTOEBOTTOM_H
#define P_VECTORNAV_TO_RIGHTTOEBOTTOM_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_VectorNav_to_RightToeBottom(const Eigen::Matrix<double,14,1> &var1);

#endif 


