/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:35 GMT-05:00
 */

#ifndef R_ANKLE_JOINT_RIGHT_H
#define R_ANKLE_JOINT_RIGHT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_ankle_joint_right(const Eigen::Matrix<double,20,1> &var1);

#endif 


