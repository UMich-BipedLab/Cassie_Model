/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:08 GMT-05:00
 */

#ifndef R_BASEROTY_H
#define R_BASEROTY_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_BaseRotY(const Eigen::Matrix<double,20,1> &var1);

#endif 


