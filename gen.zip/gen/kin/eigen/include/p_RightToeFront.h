/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:48 GMT-05:00
 */

#ifndef P_RIGHTTOEFRONT_H
#define P_RIGHTTOEFRONT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_RightToeFront(const Eigen::Matrix<double,20,1> &var1);

#endif 


