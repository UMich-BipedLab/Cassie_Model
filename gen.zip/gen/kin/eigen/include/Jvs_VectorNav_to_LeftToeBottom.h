/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 23:21:10 GMT-05:00
 */

#ifndef JVS_VECTORNAV_TO_LEFTTOEBOTTOM_H
#define JVS_VECTORNAV_TO_LEFTTOEBOTTOM_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,14> Jvs_VectorNav_to_LeftToeBottom(const Eigen::Matrix<double,14,1> &var1);

#endif 


