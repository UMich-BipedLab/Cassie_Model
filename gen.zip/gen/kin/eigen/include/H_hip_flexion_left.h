/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:13 GMT-05:00
 */

#ifndef H_HIP_FLEXION_LEFT_H
#define H_HIP_FLEXION_LEFT_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_hip_flexion_left(const Eigen::Matrix<double,20,1> &var1);

#endif 


