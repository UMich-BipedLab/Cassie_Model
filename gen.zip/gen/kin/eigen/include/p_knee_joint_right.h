/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:29 GMT-05:00
 */

#ifndef P_KNEE_JOINT_RIGHT_H
#define P_KNEE_JOINT_RIGHT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_knee_joint_right(const Eigen::Matrix<double,20,1> &var1);

#endif 


