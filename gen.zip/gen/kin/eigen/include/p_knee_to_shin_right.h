/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:31 GMT-05:00
 */

#ifndef P_KNEE_TO_SHIN_RIGHT_H
#define P_KNEE_TO_SHIN_RIGHT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_knee_to_shin_right(const Eigen::Matrix<double,20,1> &var1);

#endif 


