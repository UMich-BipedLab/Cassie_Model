/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:43 GMT-05:00
 */

#ifndef R_LEFTTOEFRONT_H
#define R_LEFTTOEFRONT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_LeftToeFront(const Eigen::Matrix<double,20,1> &var1);

#endif 


