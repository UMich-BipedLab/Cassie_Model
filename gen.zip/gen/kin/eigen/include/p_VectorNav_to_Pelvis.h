/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 23:02:36 GMT-05:00
 */

#ifndef P_VECTORNAV_TO_PELVIS_H
#define P_VECTORNAV_TO_PELVIS_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_VectorNav_to_Pelvis(const Eigen::Matrix<double,14,1> &var1);

#endif 


