/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:02 GMT-05:00
 */

#ifndef P_BASEPOSX_H
#define P_BASEPOSX_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_BasePosX(const Eigen::Matrix<double,20,1> &var1);

#endif 


