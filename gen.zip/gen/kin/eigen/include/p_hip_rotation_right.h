/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:25 GMT-05:00
 */

#ifndef P_HIP_ROTATION_RIGHT_H
#define P_HIP_ROTATION_RIGHT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_hip_rotation_right(const Eigen::Matrix<double,20,1> &var1);

#endif 


