/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:37 GMT-05:00
 */

#ifndef H_TOE_JOINT_RIGHT_H
#define H_TOE_JOINT_RIGHT_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_toe_joint_right(const Eigen::Matrix<double,20,1> &var1);

#endif 


