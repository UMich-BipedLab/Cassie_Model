/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:07 GMT-05:00
 */

#ifndef P_BASEROTY_H
#define P_BASEROTY_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_BaseRotY(const Eigen::Matrix<double,20,1> &var1);

#endif 


