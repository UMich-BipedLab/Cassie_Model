/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:04 GMT-05:00
 */

#ifndef H_BASEPOSY_H
#define H_BASEPOSY_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_BasePosY(const Eigen::Matrix<double,20,1> &var1);

#endif 


