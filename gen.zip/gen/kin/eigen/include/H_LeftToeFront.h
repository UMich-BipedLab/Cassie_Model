/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:42 GMT-05:00
 */

#ifndef H_LEFTTOEFRONT_H
#define H_LEFTTOEFRONT_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_LeftToeFront(const Eigen::Matrix<double,20,1> &var1);

#endif 


