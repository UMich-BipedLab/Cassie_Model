/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:06 GMT-05:00
 */

#ifndef P_BASEROTZ_H
#define P_BASEROTZ_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,1> p_BaseRotZ(const Eigen::Matrix<double,20,1> &var1);

#endif 


