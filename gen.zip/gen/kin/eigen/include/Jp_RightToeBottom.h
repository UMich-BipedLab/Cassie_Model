/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:47 GMT-05:00
 */

#ifndef JP_RIGHTTOEBOTTOM_H
#define JP_RIGHTTOEBOTTOM_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,20> Jp_RightToeBottom(const Eigen::Matrix<double,20,1> &var1);

#endif 


