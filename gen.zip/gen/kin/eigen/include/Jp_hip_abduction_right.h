/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:23 GMT-05:00
 */

#ifndef JP_HIP_ABDUCTION_RIGHT_H
#define JP_HIP_ABDUCTION_RIGHT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,20> Jp_hip_abduction_right(const Eigen::Matrix<double,20,1> &var1);

#endif 


