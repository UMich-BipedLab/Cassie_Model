/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:26 GMT-05:00
 */

#ifndef R_HIP_ROTATION_RIGHT_H
#define R_HIP_ROTATION_RIGHT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_hip_rotation_right(const Eigen::Matrix<double,20,1> &var1);

#endif 


