/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:47 GMT-05:00
 */

#ifndef H_RIGHTTOEBOTTOM_H
#define H_RIGHTTOEBOTTOM_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_RightToeBottom(const Eigen::Matrix<double,20,1> &var1);

#endif 


