/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 23:22:19 GMT-05:00
 */

#ifndef JVB_LEFTTOEBOTTOM_TO_RIGHTTOEBOTTOM_H
#define JVB_LEFTTOEBOTTOM_TO_RIGHTTOEBOTTOM_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,14> Jvb_LeftToeBottom_to_RightToeBottom(const Eigen::Matrix<double,14,1> &var1);

#endif 


