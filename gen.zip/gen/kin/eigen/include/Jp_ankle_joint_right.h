/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:34 GMT-05:00
 */

#ifndef JP_ANKLE_JOINT_RIGHT_H
#define JP_ANKLE_JOINT_RIGHT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,20> Jp_ankle_joint_right(const Eigen::Matrix<double,20,1> &var1);

#endif 


