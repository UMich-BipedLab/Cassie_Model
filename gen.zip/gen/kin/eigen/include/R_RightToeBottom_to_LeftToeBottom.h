/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 23:02:44 GMT-05:00
 */

#ifndef R_RIGHTTOEBOTTOM_TO_LEFTTOEBOTTOM_H
#define R_RIGHTTOEBOTTOM_TO_LEFTTOEBOTTOM_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_RightToeBottom_to_LeftToeBottom(const Eigen::Matrix<double,14,1> &var1);

#endif 


