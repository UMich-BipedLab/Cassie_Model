/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:05 GMT-05:00
 */

#ifndef H_BASEPOSZ_H
#define H_BASEPOSZ_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_BasePosZ(const Eigen::Matrix<double,20,1> &var1);

#endif 


