/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:22 GMT-05:00
 */

#ifndef R_TOE_JOINT_LEFT_H
#define R_TOE_JOINT_LEFT_H
#include <Eigen/Dense>

Eigen::Matrix<double,3,3> R_toe_joint_left(const Eigen::Matrix<double,20,1> &var1);

#endif 


