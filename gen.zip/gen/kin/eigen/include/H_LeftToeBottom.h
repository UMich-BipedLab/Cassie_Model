/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:44:40 GMT-05:00
 */

#ifndef H_LEFTTOEBOTTOM_H
#define H_LEFTTOEBOTTOM_H
#include <Eigen/Dense>

Eigen::Matrix<double,4,4> H_LeftToeBottom(const Eigen::Matrix<double,20,1> &var1);

#endif 


