/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:43:37 GMT-05:00
 */

#ifndef R_ANKLE_JOINT_LEFT_SRC_H
#define R_ANKLE_JOINT_LEFT_SRC_H

#ifdef MATLAB_MEX_FILE
#include <tmwtypes.h>
#else
#include "rtwtypes.h"
#endif

void R_ankle_joint_left_src(double *p_output1, const double *var1);

#endif 
/* R_ANKLE_JOINT_LEFT_SRC_H */
