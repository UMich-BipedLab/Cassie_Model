/*
 * Automatically Generated from Mathematica.
 * Tue 8 Jan 2019 22:43:42 GMT-05:00
 */

#ifndef H_HIP_FLEXION_RIGHT_SRC_H
#define H_HIP_FLEXION_RIGHT_SRC_H

#ifdef MATLAB_MEX_FILE
#include <tmwtypes.h>
#else
#include "rtwtypes.h"
#endif

void H_hip_flexion_right_src(double *p_output1, const double *var1);

#endif 
/* H_HIP_FLEXION_RIGHT_SRC_H */
